OS: windows/ubuntu/Mac OS

launch: windows: main.cmd (if you have some wired characters, try main_utf-8.cmd)
        Mac OS/ubuntu: main.sh (if you have some wired characters, try main_utf-8.cmd)

enter user name.
click "find nearby user" button to find nearby users.
clicking other's login name to generate text areas, then you can read all
the messages received from that user.
the text area above is to display received messages. The text area below is to type
messges you need to send.
the tool bar allows you to change background color of text areas.
when yo finish typing, click send button to send send messges.
change the source language and target language to enable translation
UI button enable you to change UI.

by clicking "single" button, you can switch to multiple mode.
Then you can select multiple users, which allows you to display and send messages to
multiple users, the same as group chat.
